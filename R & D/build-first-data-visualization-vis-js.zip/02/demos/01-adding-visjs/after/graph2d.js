(function () {
    const container = document.getElementById('graph2d');
    new vis.Graph2d(container);
})();
